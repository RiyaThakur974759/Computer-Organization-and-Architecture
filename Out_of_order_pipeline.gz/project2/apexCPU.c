#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "apexCPU.h"
#include "apexMem.h"

/*---------------------------------------------------------
   Internal function declarations
---------------------------------------------------------*/
void cycle_fetch(cpu cpu);
void cycle_decode(cpu cpu);
void cycle_dispatch(cpu cpu);
void cycle_stage(cpu cpu,int stage);
char * getInum(cpu cpu,int pc);
void reportReg(cpu cpu,int r);
void reportPReg(cpu cpu,int r);
void reportRAT(cpu cpu,int r);
char * statusString(enum stageStatus_enum st);

/*---------------------------------------------------------
   Global Variables
---------------------------------------------------------*/
char *stageName[writeback+1]={"fetch","decode","dispatch",
	"mul1","mul2","mul3",
	"alu1",//"alu2","alu3",
	"load1",//"load2","load3",
	//"store1",//"store2","store3",
	"branch1",//"branch2","branch3",
	"writeback"};
extern opStageFn opFns[writeback+1][NUMOPS]; // Array of function pointers, one for each stage/opcode combination
enum stage_enum pipeEnd[writeback+1]={
	decode, // For fetch
	decode, // For decode
	dispatch,
	fu_mul3, fu_mul3, fu_mul3, // for mul fu
	fu_alu1,// fu_alu3, fu_alu3, // for alu fu
	fu_ld1,// fu_ld3, fu_ld3, // for load fu
	//fu_st1,// fu_st3, fu_st3, // for store fu
	fu_br1,// fu_br3, fu_br3, // for br fu
	writeback // for writeback
};

/*---------------------------------------------------------
   External Function definitions
---------------------------------------------------------*/

void initCPU(cpu cpu) {
	cpu->pc=0x4000;
	cpu->nextfreeprf=0;
	cpu->headiq=0;
	cpu->tailiq=0;
	cpu->headrob=0;
	cpu->tailrob=0;
	cpu->headlsq=0;
	cpu->taillsq=0;
	cpu->lsqindex=0;
	cpu->cc_common=-1;
	cpu->numInstructions=0;
	cpu->lowMem=128;
	cpu->highMem=-1;
	for(int i=0;i<16;i++) {
		cpu->reg[i]=0xdeadbeef;
		cpu->regValid[i]=1;                 // all registers start out as "valid"
		cpu->PRF[i].value=0xdeadbeef;       // all PRF registers start out as "valid"
		cpu->PRF[i].valid=-1;
		cpu->RAT[i].valid=-1;                 // RAT values are 0 means not mapped to prf
		cpu->RAT[i].prf=0xdeadbeef;
		cpu->rob_struct[i].alloc = -1; //Empty Rob
		cpu->rob_struct[i].pc_val = 0000;
		cpu->rob_struct[i].ar_val = 0;
		cpu->LSQ_struct[i].a = -1;
		cpu->rob_struct[i].ls_index = -1;
	}
	for(int i=0;i<5;i++){
		cpu->IQ[i].alloc=0;
		cpu->IQ[i].op=0;
		cpu->IQ[i].fu=0;
		cpu->IQ[i].s1valid=0;
		cpu->IQ[i].s1tag=0;
		cpu->IQ[i].s1val=0;
		cpu->IQ[i].s2valid=0;
		cpu->IQ[i].s2tag=0;
		cpu->IQ[i].s2val=0;
		cpu->IQ[i].LP=0;
		cpu->IQ[i].dest=0;
	}
	// cpu->IQ[0].source1.valid=0;
	cpu->cc.z=cpu->cc.p=0;
	cpu->t=0;
	cpu->instr_retired=0;
	cpu->halt_fetch=0;
	cpu->stop=0;
	for(enum stage_enum i=fetch;i<=writeback;i++) {
		cpu->stage[i].status=stage_squashed;
		cpu->stage[i].report[0]='\0';
		reportStage(cpu,i,"---");
		cpu->stage[i].instruction=0;
		cpu->stage[i].opcode=0;
		cpu->stage[i].pc=-1;
		cpu->stage[i].branch_taken=0;
		cpu->stage[i].fu=no_fu;
		for(int op=0;op<NUMOPS;op++) opFns[i][op]=NULL;
	}
	for (int c=2; c>=0; c--) cpu->fwdBus[c].valid=0;
	registerAllOpcodes();
}

//open obect file and every line in object file and check in memory --- todo
void loadCPU(cpu cpu,char * objFileName) {
	char cmtBuf[128];
	FILE * objF=fopen(objFileName,"r");
	if (objF==NULL) {
		perror("Error - unable to open object file for read");
		printf("...Trying to read from object file %s\n",objFileName);
		return;
	}

	int nread=0;
	while(!feof(objF)) {
		int newInst;
		if (1==fscanf(objF," %08x",&newInst)) {
			cpu->codeMem[nread++]=newInst;
		} else if (1==fscanf(objF,"; %127[^\n]\n",cmtBuf)) {
			// Ignore comments on the same line
			// printf("Ignoring commment: %s\n",cmtBuf);
		} else {
			fscanf(objF," %s ",cmtBuf);
			printf("Load aborted, unrecognized object code: %s\n",cmtBuf);
			return;
		}
	}
	cpu->numInstructions=nread;
	cpu->pc=0x4000;
	cpu->halt_fetch=cpu->stop=0;
	printf("Loaded %d instructions starting at adress 0x4000\n",nread);
}

void printState(cpu cpu) {

	printf("\nCPU state at cycle %d, pc=0x%08x, cc.z=%s cc.p=%s\n",
		cpu->t,cpu->pc,cpu->cc.z?"true":"false",cpu->cc.p?"true":"false");

	printf("Stage Info:\n");
	char instBuf[32];
	for (int s=0;s<=writeback;s++) {
		if (cpu->stage[s].status==stage_noAction) continue;
		if (cpu->stage[s].status==stage_squashed) continue;
	   // if (cpu->stage[s].status==stage_stalled) continue;
		printf("  %10s: pc=%05x %s",stageName[s],cpu->stage[s].pc,disassemble(cpu->stage[s].instruction,instBuf));
		//f (cpu->stage[s].status==stage_squashed) printf(" squashed");
		//if (cpu->stage[s].status==stage_stalled) printf(" stalled");
		//printf("\nthe stage is:\n ");
		printf(" %s\n",cpu->stage[s].report);
	}

	printf("\n Int Regs: \n   ");
	for(int r=0;r<16;r++) reportReg(cpu,r);
	printf("\n");

	printf("\n Int Phy Regs: \n   ");
	for(int r=0;r<16;r++) reportPReg(cpu,r);
	printf("\n");
	
	printf("\n RAT: \n   ");
	for(int r=0;r<16;r++) reportRAT(cpu,r);
	printf("\n");

	if ((cpu->lowMem<128) && (cpu->highMem>-1)) {
		printf("Modified memory:\n");
		for(int i=cpu->lowMem;i<=cpu->highMem;i++) {
			printf("MEM[%04x]=%d\n",i*4,cpu->dataMem[i]);
		}
		printf("\n");
	}

	printf("Forwarding buses:\n");
	for(int c=0;c<3;c++) {
		if (cpu->fwdBus[c].valid) {
			printf("   bus %d: R%d, value=%d\n",c,cpu->fwdBus[c].tag,cpu->fwdBus[c].value);
		}
	}
	printf("\n");

	//IQ
	printf("IQ :\n");
	printf("|allc| op  | fu | s1v| s1t|s1va| s2v| s2t|s2va| L/P|dest|\n");
	for(int i=0;i<5;i++) {
		if (cpu->IQ[i].alloc==1) {
			printf("|  %d |  %d  |  %d |  %d |  %d |  %d |  %d |  %d |  %d |  %d |  %d |\n",cpu->IQ[i].alloc,cpu->IQ[i].op,cpu->IQ[i].fu,cpu->IQ[i].s1valid,cpu->IQ[i].s1tag,cpu->IQ[i].s1val,cpu->IQ[i].s2valid,cpu->IQ[i].s2tag,cpu->IQ[i].s2val,cpu->IQ[i].LP,cpu->IQ[i].dest);
		}
	}
	printf("\n");
	printf("ROB:\n");
	printf("|A| PC   |AR|PR|LSQ|\n");
	for(int i=0;i<16;i++){
		if(cpu->rob_struct[i].alloc == 1 ){
			if(cpu->rob_struct[i].ls_index == -1){
				printf("|%d|%05x|R%d|P%d|---|\n",cpu->rob_struct[i].alloc,cpu->rob_struct[i].pc_val,cpu->rob_struct[i].ar_val,cpu->rob_struct[i].pr_val);
			}
			else if(cpu->rob_struct[i].ls_index != -1 && (cpu->stage[decode].opcode == 10 ||cpu->stage[decode].opcode == 11 )){
		     printf("|%d|%05x|R%d|P%d|L%d |\n",cpu->rob_struct[i].alloc,cpu->rob_struct[i].pc_val,cpu->rob_struct[i].ar_val,cpu->rob_struct[i].pr_val,cpu->rob_struct[i].ls_index);
		     } //else if(cpu->rob_struct[i].ls_index == -1 && cpu->stage[decode].opcode== 12){
			//  	printf("|%d|%05x|--|--|--- |\n",cpu->rob_struct[i].alloc,cpu->rob_struct[i].pc_val);
			// }

		}
		//printf("|0|0000|A0|P0|0|\n");
	}

	printf("\n");
	printf("LSQ: Load is 1 | Store is 2\n");
	printf("|Index| A   |L/S|v|Tag|Value|v|Address|Z|P|Dest|\n");
	for(int i=0;i<5;i++){
		if(cpu->LSQ_struct[i].a == 1){
			if(cpu->LSQ_struct[i].ls== 1){
			//printf("|L%d   | %d   | %d |v|Tag|Value|v|Address|Z|P|P%d|\n", i,cpu->LSQ_struct[i].a,cpu->LSQ_struct[i].ls,cpu->LSQ_struct[i].dest);
			printf("|L%d   | %d   | %d |-|---|----|%d |??     |?|?|P%d|\n", i,cpu->LSQ_struct[i].a,cpu->LSQ_struct[i].ls,cpu->LSQ_struct[i].addv,cpu->LSQ_struct[i].dest);
			}
			else if(cpu->LSQ_struct[i].ls== 2){
				printf("|L%d   | %d   | %d |%d|Tag|Value|%d|Address|Z|P|--|\n", i,cpu->LSQ_struct[i].a,cpu->LSQ_struct[i].ls,cpu->LSQ_struct[i].v,cpu->LSQ_struct[i].addv);
			}
		}
	}
	printf("\n");

	if (cpu->halt_fetch) {
		printf("Instruction fetch is halted.\n");
	}
	if (cpu->stop) {
		printf("CPU is stopped because %s\n",cpu->abend);
	}
}

void cycleCPU(cpu cpu) {
	if (cpu->stop) {
		printf("CPU is stopped for %s. No cycles allowed.\n",cpu->abend);
		return;
	}
	
	// First, cycle stage data from FU to WB
	// Resolve which FU forwards to WB (if any)
	cpu->stage[writeback].status=stage_noAction;
	for(enum stage_enum fu=fu_mul3; fu<=fu_br1 && cpu->stage[writeback].status==stage_noAction; fu+=1) {
		if (cpu->stage[fu].status==stage_actionComplete) {
			cpu->stage[writeback]=cpu->stage[fu];
			cpu->stage[writeback].status=stage_ready;
			cpu->stage[fu].status=stage_noAction; // Available for new
			//cpu->stage[fu].status=stage_noAction; // Open up for issue
			// cpu->stage[fu].instruction=0;
			// cpu->stage[fu].opcode=0;
			// cpu->stage[fu].pc=-1;
		}
	}

	if (cpu->stage[writeback].status==stage_noAction) {
		cpu->stage[writeback].status=stage_stalled; // Nothing is ready to writeback
		cpu->stage[writeback].pc=-1;
	}


	//free after forwarding
	for(enum fu_enum fs=alu_fu; fs<=br_fu; fs+=1) {
		if (cpu->stage[decode].opcode!=fs && cpu->stage[decode].status!=stage_noAction) {
			cpu->stage[fs].status=stage_noAction; // Open up for issue
			cpu->stage[fs].instruction=0;
			cpu->stage[fs].opcode=0;
			cpu->stage[fs].pc=-1;
		}
	}




	//for(
	enum fu_enum fs=mult_fu;// fs<=br_fu; fs+=3) {
		if (cpu->stage[fs+2].status==stage_noAction ||
				cpu->stage[fs+2].status==stage_squashed) {
			cpu->stage[fs+2]=cpu->stage[fs+1];
			cpu->stage[fs+1]=cpu->stage[fs];
			cpu->stage[fs].status=stage_noAction; // Open up for issue
			cpu->stage[fs].instruction=0;
			cpu->stage[fs].opcode=0;
			cpu->stage[fs].pc=-1;
		}
	//}
	

	cycle_dispatch(cpu); //  dispatch/issue any decoded instruction to an FU


	if (cpu->stage[dispatch].status!=stage_stalled) {
		if (cpu->stage[decode].status==stage_stalled ) {
			cpu->stage[dispatch].status=stage_squashed;
			cpu->stage[dispatch].instruction=0;
			cpu->stage[dispatch].opcode=0;
		} else {
			cpu->stage[dispatch]=cpu->stage[decode];
			// Reset the decode stage
			cpu->stage[decode].status=stage_squashed; // No valid instruction available yet
			cpu->stage[decode].instruction=0;
			cpu->stage[decode].opcode=0;
		} // end of decode not stalled
	} // end of dispatch not stalled

	// Next, cycle stage data from Fetch to Decode and reset Fetch
	if (cpu->stage[decode].status!=stage_stalled) {
		if (cpu->stage[fetch].status==stage_stalled ) {
			cpu->stage[decode].status=stage_squashed;
			cpu->stage[decode].instruction=0;
			cpu->stage[decode].opcode=0;
		} else {
			cpu->stage[decode]=cpu->stage[fetch];
			// Reset the fetch stage
			cpu->stage[fetch].status=stage_squashed; // No valid instruction available yet
			cpu->stage[fetch].instruction=0;
			cpu->stage[fetch].opcode=0;
		} // end of fetch not stalled
	} // end of decode not stalled

	// Move data forward in the forwarding busses
	for (int c=2; c>0;c--) {
		cpu->fwdBus[c]=cpu->fwdBus[c-1]; // Copy all fields forward
	}
	cpu->fwdBus[0].valid=0;
	// NOTE: fowarding bus conflicts due to different FU completion times!
	//	Conflict always "won" by latest instruction in program order
	//   Hence, if a bus is valid, it should not be overwritten by an
	//   instruction which finished later, but was earlier in the program
	//   order.

	// Reset the reports and status as required for all stages
	for(int s=0;s<=writeback+1;s++) {
		cpu->stage[s].report[0]='\0';
		switch (cpu->stage[s].status) {
			case stage_squashed:
			case stage_stalled:
			case stage_noAction:
			case stage_ready:
				break; // No change required
			case stage_actionComplete:
				cpu->stage[s].status=stage_noAction; // Overwrite previous stages status
		}
	}
	

	if (!cpu->stop) cycle_fetch(cpu);
	if (!cpu->stop) cycle_decode(cpu); // Do the decode part of d/rf
	if (!cpu->stop) cycle_stage(cpu,dispatch);
	
	for(enum fu_enum fu=mult_fu; fu<=br_fu+2; fu++) {
		if (!cpu->stop) cycle_stage(cpu,fu);
	}


	if (!cpu->stop && cpu->stage[writeback].status==stage_ready) cycle_stage(cpu,writeback);

	if (!cpu->stop) cycle_stage(cpu,decode); // Do the rf part of d/rf

	cpu->t++; // update the clock tick - This cycle has completed
	// if (cpu->t==1) {
	// 	printf("      |ftch|deco|mul1|mul2|mul3|alu1|alu2|alu3|lod1|lod2|lod3|sto1|sto2|sto3|br1 |br2 |br3 | wb |\n");
	// }
	if (cpu->t==1) {
		printf("      |ftch|deco|disp|mul1|mul2|mul3|alu1|ld/s|br1 | wb |\n");
	}

	// Report on all stages (move this before cycling the rf part of decode to match Kanad's results)
	printf ("t=%3d |",cpu->t);
	for(int s=0;s<=writeback;s++) {
		int stalled=0;
		for(int f=s;f<=pipeEnd[s];f++) if (cpu->stage[f].status==stage_stalled) stalled=1;
		if (stalled) printf ("%3ss|", getInum(cpu,cpu->stage[s].pc));
		else {
			switch(cpu->stage[s].status) {
				case stage_squashed: printf("   q|"); break;
				case stage_stalled: break; // printed stalled above
				case stage_noAction: printf ("%3s-|", getInum(cpu,cpu->stage[s].pc)); break;
				case stage_ready: printf ("%3sr|", getInum(cpu,cpu->stage[s].pc)); break;
				case stage_actionComplete: printf("%3s+|", getInum(cpu,cpu->stage[s].pc)); break;
			}
		}

	}
	printf("\n");

	// if (!cpu->stop) cycle_stage(cpu,decode); // Do the rf part of d/rf

	if (cpu->stop) {
		printf("CPU stopped because %s\n",cpu->abend);
	}
}

void printStats(cpu cpu) {
	printf("\nAPEX Simulation complete.\n");
	printf("    Total cycles executed: %d\n",cpu->t);
	printf("    Instructions retired: %d\n",cpu->instr_retired);
	printf("    Instructions per Cycle (IPC): %5.3f\n",((float)cpu->instr_retired)/cpu->t);
	printf("    Stop is %s\n",cpu->stop?"true":"false");
	if (cpu->stop) {
		printf("    Reason for stop: %s\n",cpu->abend);
	}
}

void reportStage(cpu cpu,enum stage_enum s,const char* fmt,...) {
	char msgBuf[1024]={0};
	va_list args;
	va_start(args,fmt);
	vsprintf(msgBuf,fmt,args);
	va_end(args);
	// Truncate msgBuf to fit
	if (strlen(msgBuf)+strlen(cpu->stage[s].report) >=128) {
		msgBuf[127-strlen(cpu->stage[s].report)]='\0';
	}
	strcat(cpu->stage[s].report,msgBuf);
}

/*---------------------------------------------------------
   Internal Function definitions
---------------------------------------------------------*/

void cycle_fetch(cpu cpu) {
	// Don't run if anything downstream is stalled
	for(int s=1;s<7;s++) if (cpu->stage[s].status==stage_stalled) return;
	if (cpu->halt_fetch) {
		cpu->stage[fetch].status=stage_squashed;
		cpu->stage[fetch].instruction=0;
		cpu->stage[fetch].opcode=0;
		return;
	}
	for(int i=0;i<16;i++){
		if(cpu->PRF[i].valid==-1){
			cpu->nextfreeprf=i;
			// cpu->PRF[i].valid=0;
			break;
		}
	}
	int inst=ifetch(cpu);
	if (!cpu->stop) {
		cpu->stage[fetch].status=stage_noAction;
		cpu->stage[fetch].instruction=inst;
		//printf("%d",cpu->stage[fetch].instruction);
		cpu->stage[fetch].opcode=(inst>>24);
		if (cpu->stage[fetch].opcode<0 || cpu->stage[fetch].opcode>HALT) {
			cpu->stop=1;
			sprintf(cpu->abend,"Invalid opcode %x after ifetch(%08x)",
				cpu->stage[fetch].opcode,cpu->pc);
			return;
		}
		reportStage(cpu,fetch,"ifetch %s",getInum(cpu,cpu->pc));
		if (cpu->stage[fetch].opcode==HALT) {
			cpu->halt_fetch=1; // Stop fetching when the HALT instruction is fetched
			reportStage(cpu,fetch," --- fetch halted");
		}
		cpu->stage[fetch].pc=cpu->pc;
		cpu->stage[fetch].status=stage_actionComplete;
		cpu->pc+=4;
	}
}

void cycle_decode(cpu cpu) {
	// Does the first half (the decode part) of the decode/fetch regs stage
	if (cpu->stage[decode].status==stage_squashed) return;
	if (cpu->stage[decode].status==stage_stalled) return; // Decode already done
	enum opFormat_enum fmt=opInfo[cpu->stage[decode].opcode].format;
	int inst=cpu->stage[decode].instruction;
	cpu->stage[decode].op1Valid=1;
	cpu->stage[decode].op2Valid=1;
	switch(fmt) {
		case fmt_nop:
			reportStage(cpu,decode,"decode(nop)");
			cpu->stage[decode].fu=alu_fu;
			cpu->stage[decode].status=stage_actionComplete;
			break; // No decoding required
		case fmt_dss:
			cpu->stage[decode].dr=(inst&0x00f00000)>>20;
			cpu->stage[decode].sr1=(inst&0x000f0000)>>16;
			cpu->stage[decode].op1Valid=0;
			cpu->stage[decode].sr2=(inst&0x0000f000)>>12;
			cpu->stage[decode].op2Valid=0;
			cpu->stage[decode].fu=alu_fu;
			if (cpu->stage[decode].opcode==MUL) cpu->stage[decode].fu=mult_fu;
			reportStage(cpu,decode,"decode(dss)");
			break;
		case fmt_dsi:
			cpu->stage[decode].dr=(inst&0x00f00000)>>20;
			cpu->stage[decode].sr1=(inst&0x000f0000)>>16;
			cpu->stage[decode].op1Valid=0;
			cpu->stage[decode].imm=((inst&0x0000ffff)<<16)>>16;
			cpu->stage[decode].op2=cpu->stage[decode].imm;
			cpu->stage[decode].op2Valid=1;
			if (cpu->stage[decode].opcode==LOAD) cpu->stage[decode].fu=load_fu;
			else cpu->stage[decode].fu=alu_fu;
			reportStage(cpu,decode,"decode(dsi) op2=%d",cpu->stage[decode].op2);
			break;
		case fmt_di:
			cpu->stage[decode].dr=(inst&0x00f00000)>>20;
			cpu->stage[decode].imm=((inst&0x0000ffff)<<16)>>16; // Shift left/right to propagate sign bit
			cpu->stage[decode].op1=cpu->stage[decode].imm;
			cpu->stage[decode].op1Valid=1;
			cpu->stage[decode].op2Valid=1;
			cpu->stage[decode].fu=alu_fu;
			reportStage(cpu,decode,"decode(di) op1=%d",cpu->stage[decode].op1);
			break;
		case fmt_ssi:
			cpu->stage[decode].sr1=(inst&0x00f00000)>>20;
			cpu->stage[decode].op1Valid=0;
			cpu->stage[decode].sr2=(inst&0x000f0000)>>16;
			cpu->stage[decode].op2Valid=0;
			cpu->stage[decode].imm=((inst&0x0000ffff)<<16)>>16;
			cpu->stage[decode].fu=load_fu;
			reportStage(cpu,decode,"decode(ssi) imm=%d",cpu->stage[decode].imm);
			break;
		case fmt_ss:
			cpu->stage[decode].sr1=(inst&0x000f0000)>>16;
			cpu->stage[decode].op1Valid=0;
			cpu->stage[decode].sr2=(inst&0x0000f000)>>12;
			cpu->stage[decode].op2Valid=0;
			reportStage(cpu,decode,"decode(ss)");
			cpu->stage[decode].fu=alu_fu;
			break;
		case fmt_off:
			cpu->stage[decode].offset=((inst&0x0000ffff)<<16)>>16;
			cpu->stage[decode].op1Valid=1;
			cpu->stage[decode].op2Valid=1;
			reportStage(cpu,decode,"decode(off)");
			cpu->stage[decode].fu=br_fu;
			break;
		default :
			cpu->stop=1;
			sprintf(cpu->abend,"Decode format %d not recognized in cycle_decode",fmt);
	}
// 	if(cpu->stage[decode].status!= stage_stalled){
// 	for (int i=0;i<16;i++){
// 		if(cpu->rob_struct[i].alloc == -1){
// 			{
// 			cpu->rob_struct[i].alloc = 1;
// 			if(cpu->stage[decode].dr!=-1){
// 				if(cpu->stage[decode].opcode==18){
// 				cpu->rob_struct[i].ar_val = 0;
// 				cpu->rob_struct[i].pc_val = cpu->stage[decode].pc;
// 				//exit(0);
// 				break;
// 				}else{
// 				cpu->rob_struct[i].ar_val = cpu->stage[decode].dr;
// 				cpu->rob_struct[i].pc_val = cpu->stage[decode].pc;
// 				cpu->rob_struct[i].pr_val = cpu->RAT[cpu->rob_struct[i].ar_val].prf;

// 				//printf("\n THis is  physical reg: %d",cpu->RAT[cpu->stage[decode].dr].prf );
// 				//cpu->rob_struct[i].pr_val = cpu->RAT[i].prf;
// 				}
// 				//printf("This is the pc: %d\t",cpu->rob_struct[i].pc_val);
// 			}
// 			break;
// 			}
// 				break;
//         }
		
//     } 
// }
}

void cycle_dispatch(cpu cpu) {
	// if (cpu->stage[dispatch].status!=stage_actionComplete) return;
	// // Move decoded instruction onto fu
	// enum fu_enum fu=cpu->stage[dispatch].fu;
	// if (cpu->stage[fu].status==stage_noAction ||
	// 		cpu->stage[fu].status==stage_squashed ||
	// 		cpu->stage[fu].status==stage_actionComplete) {
	// 	// fu is available...
	// 	// Don't issue until operands are available
	// 	// Operands are valid... issue to fu
	// 	cpu->stage[fu]=cpu->stage[dispatch];
	// 	cpu->stage[fu].status=stage_ready;
	// 	cpu->stage[fu].report[0]='\0';
	// 	reportStage(cpu,dispatch," issued to fu %d",fu);
	// 	cpu->stage[dispatch].status=stage_actionComplete;
	// } else {
	// 	// fu is not available, issue needs to stall
	// 	reportStage(cpu,dispatch,"Required FU busy, status=%s",
	// 		statusString(cpu->stage[fu].status));
	// 	cpu->stage[dispatch].status=stage_stalled;
	// }
	
	// cpu->IQ[cpu->tailiq].alloc=1;
	// cpu->IQ[cpu->tailiq].op=cpu->stage[dispatch].opcode;
	// cpu->tailiq=cpu->tailiq+1;
	// if(cpu->tailiq==10){
	// 	if(cpu->headiq!=0){
	// 	cpu->tailiq=0;
	// 	}
	// 	else{
	// 		cpu->stage[dispatch].status=stage_stalled;
	// 	}
	// }
	if (cpu->stage[dispatch].status!=stage_actionComplete) return;
	// Move decoded instruction onto fu
	enum fu_enum fu=cpu->stage[dispatch].fu;
	if (cpu->stage[fu].status==stage_noAction ||
			cpu->stage[fu].status==stage_squashed ||
			cpu->stage[fu].status==stage_actionComplete) {
		// fu is available...
		// Don't issue until operands are available
		// Operands are valid... issue to fu
		cpu->stage[fu]=cpu->stage[dispatch];
		cpu->stage[fu].status=stage_ready;
		cpu->stage[fu].report[0]='\0';
		reportStage(cpu,dispatch," issued to fu %d",fu);
		cpu->stage[dispatch].status=stage_actionComplete;
	} else {
		// fu is not available, issue needs to stall
		reportStage(cpu,dispatch,"Required FU busy, status=%s",
			statusString(cpu->stage[fu].status));
		cpu->stage[dispatch].status=stage_stalled;
	}

	
	cpu->IQ[cpu->tailiq].alloc=1;
	cpu->IQ[cpu->tailiq].op=cpu->stage[dispatch].opcode;
	if(cpu->IQ[cpu->tailiq].op==MOVC){
		cpu->IQ[cpu->tailiq].s1valid=1;
		cpu->IQ[cpu->tailiq].s1val=cpu->stage[dispatch].op1;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].LP=2;
		cpu->tailiq=cpu->tailiq+1;

	}
	else if(cpu->IQ[cpu->tailiq].op==LOAD){
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].valid;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].value;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].s2val=cpu->stage[dispatch].sr1;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;

	}
	else if(cpu->IQ[cpu->tailiq].op==STORE){
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].valid;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].value;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].s2val=cpu->stage[dispatch].sr2;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;
	}
	else if(cpu->IQ[cpu->tailiq].op==HALT){
		cpu->IQ[cpu->tailiq].s1valid=1;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;
	}
	else {
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].valid;
		cpu->IQ[cpu->tailiq].s1tag=cpu->RAT[cpu->stage[dispatch].sr1].prf;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].value;
		
		cpu->IQ[cpu->tailiq].s2valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].valid;
		cpu->IQ[cpu->tailiq].s2tag=cpu->RAT[cpu->stage[dispatch].sr2].prf;
		cpu->IQ[cpu->tailiq].s2val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].value;
		cpu->IQ[cpu->tailiq].LP=2;
		cpu->tailiq=cpu->tailiq+1;
	}
	
	if(cpu->tailiq==10){
		if(cpu->headiq!=0){
			cpu->tailiq=0;
		}
		else{
			cpu->stage[dispatch].status=stage_stalled;
		}
	}


}

void cycle_stage(cpu cpu,int stage) {
	for(enum stage_enum s=stage+1;s<=pipeEnd[stage];s++) {
		if (cpu->stage[s].status==stage_stalled) return; // downstream is stalled
	}
	if (cpu->stage[stage].status==stage_squashed) return;
	assert(stage>=fetch && stage<=writeback);
	assert(cpu->stage[stage].opcode>=0 && cpu->stage[stage].opcode<=HALT);
	opStageFn stageFn=opFns[stage][cpu->stage[stage].opcode];
	if (stageFn) {
		stageFn(cpu);
		if (cpu->stage[stage].status==stage_noAction ||
				cpu->stage[stage].status==stage_ready)
			cpu->stage[stage].status=stage_actionComplete;
	} // else {
		// cpu->stage[stage].status=stage_noAction;
	// }
	if (stage==writeback && cpu->stage[writeback].status!=stage_squashed) {
		cpu->instr_retired++;
	}
}

char * getInum(cpu cpu,int pc) {
	static char inumBuf[5];
	inumBuf[0]=0x00;
	if (pc==-1) return inumBuf;
	int n=(pc-0x4000)/4;
	if (n<0 || n>cpu->numInstructions) {
		cpu->stop=1;
		sprintf(cpu->abend,"in getInum, pc was %x\n",pc);
		n=-1;
	}
	sprintf(inumBuf,"I%d",n);
	return inumBuf;
}

void reportReg(cpu cpu,int r) {
	int v=cpu->reg[r];
	printf("R%02d",r);
	if (cpu->regValid[r]) {
		if (v!=0xdeadbeef) printf("=%05d ",v);
	   else printf(" ----- ");
	} else printf(" xxxxx ");
	if (7==r%8) printf("\n   ");
}

void reportRAT(cpu cpu,int r) {
	printf("R%02d",r);
	if (cpu->RAT[r].valid!=-1) {
		if (cpu->RAT[r].prf!=0xdeadbeef) printf("=%05d ",cpu->RAT[r].prf);
	   else printf(" xxxxx ");
	} else printf(" ----- ");
	if (7==r%8) printf("\n   ");
}

void reportPReg(cpu cpu,int r) {
	printf("P%02d",r);
	if (cpu->PRF[r].valid!=-1) {
		if (cpu->PRF[r].value!=0xdeadbeef) printf("=%05d ",cpu->PRF[r].value);
	   else printf(" xxxxx ");
	} else printf(" ----- ");
	if (7==r%8) printf("\n   ");
}


char * statusString(enum stageStatus_enum st) {
	switch(st) {
		case stage_squashed: return "squashed";
		case stage_stalled: return "stalled";
		case stage_noAction: return "no action";
		case stage_ready: return "ready";
		case stage_actionComplete: return "action complete";
	}
	return "???";
}