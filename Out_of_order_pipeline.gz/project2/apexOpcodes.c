#include "apexOpcodes.h"
#include "apexCPU.h"
#include "apexMem.h"
#include "apexOpInfo.h" // OpInfo definition
#include <string.h>
#include <stdio.h>
#include <assert.h>

/*---------------------------------------------------------
This file contains a C function for each opcode and
stage that needs to do work for that opcode in that
stage.

When functions for a specific opcode are registered,
the simulator will invoke that function for that operator
when the corresponding stage is cycled. A NULL
function pointer for a specific opcode/stage indicates
that no processing is required for that operation and
stage.

The registerAllOpcodes function should invoke the
registerOpcode function for EACH valid opcode. If
you add new opcodes to be simulated, code the
functions for each stage for that opcode, and add
an invocation of registerOpcode to the
registerAllOpcodes function.
---------------------------------------------------------*/

/*---------------------------------------------------------
  Helper Function Declarations
---------------------------------------------------------*/
void fetch_register1(cpu cpu);
void fetch_register2(cpu cpu);
void check_dest(cpu cpu);
void add_rob(cpu cpu);
void add_lsq(cpu cpu);
void set_ARF_conditionCodes(cpu cpu,enum stage_enum stage);
void set_PRF_conditionCodes(cpu cpu,enum stage_enum stage);
void set_conditionCodes(cpu cpu,enum stage_enum stage);
void exForward(cpu cpu,enum stage_enum stage);
void dispatch_inst(cpu cpu);
void comp_retire(cpu cpu);

/*---------------------------------------------------------
  Global Variables
---------------------------------------------------------*/
opStageFn opFns[6][NUMOPS]={NULL}; // Array of function pointers, one for each stage/opcode combination


/*---------------------------------------------------------
  Decode stage functions
---------------------------------------------------------*/
void dss_decode(cpu cpu) {
	fetch_register1(cpu);
	fetch_register2(cpu);
	check_dest(cpu);
	add_rob(cpu);
	add_lsq(cpu);
	cpu->stage[decode].status=stage_actionComplete;
}
void dsi_decode(cpu cpu) {
	fetch_register1(cpu);
	// Second operand is immediate... no fetch required
	check_dest(cpu);
	add_rob(cpu);
	add_lsq(cpu);
	cpu->stage[decode].status=stage_actionComplete;
}

void ssi_decode(cpu cpu) {
	fetch_register1(cpu);
	fetch_register2(cpu);
	add_rob(cpu);
	add_lsq(cpu);
	cpu->stage[decode].status=stage_actionComplete;
	// if (cpu->stage[decode].opcode == 11){
	// 	if(cpu->LSQ_struct[cpu->taillsq].a == -1){

	// 	}
	// }
}

void movc_decode(cpu cpu) {
	check_dest(cpu);
	add_rob(cpu);
	cpu->stage[decode].status=stage_actionComplete;
}

void cbranch_decode(cpu cpu) {
	cpu->stage[decode].branch_taken=0;
	if (cpu->stage[decode].opcode==JUMP) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BZ && cpu->cc.z) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BNZ && !cpu->cc.z) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BP && cpu->cc.p) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BNP && !cpu->cc.p) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].branch_taken) {
		// Squash instruction currently in fetch
		cpu->stage[fetch].instruction=0;
		cpu->stage[fetch].status=stage_squashed;
		reportStage(cpu,fetch," squashed by previous branch");
		cpu->halt_fetch=1;
		reportStage(cpu,decode," branch taken");
	} else {
	  reportStage(cpu,decode," branch not taken");
  }
  add_rob(cpu);
  add_lsq(cpu);
  cpu->stage[decode].status=stage_actionComplete;

}

void dispatch_inst(cpu cpu){
	if (cpu->stage[dispatch].status!=stage_actionComplete) return;
	// Move decoded instruction onto fu
	enum fu_enum fu=cpu->stage[dispatch].fu;
	if (cpu->stage[fu].status==stage_noAction ||
			cpu->stage[fu].status==stage_squashed ||
			cpu->stage[fu].status==stage_actionComplete) {
		// fu is available...
		// Don't issue until operands are available
		// Operands are valid... issue to fu
		cpu->stage[fu]=cpu->stage[dispatch];
		cpu->stage[fu].status=stage_ready;
		cpu->stage[fu].report[0]='\0';
		reportStage(cpu,dispatch," issued to fu %d",fu);
		cpu->stage[dispatch].status=stage_actionComplete;
	} else {
		// fu is not available, issue needs to stall
		// reportStage(cpu,dispatch,"Required FU busy, status=%s",
		// 	statusString(cpu->stage[fu].status));
		cpu->stage[dispatch].status=stage_stalled;
	}


	cpu->IQ[cpu->tailiq].alloc=1;
	cpu->IQ[cpu->tailiq].op=cpu->stage[dispatch].opcode;
	if(cpu->IQ[cpu->tailiq].op==MOVC){
		cpu->IQ[cpu->tailiq].s1valid=1;
		cpu->IQ[cpu->tailiq].s1val=cpu->stage[dispatch].op1;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].LP=2;
		cpu->tailiq=cpu->tailiq+1;

	}
	else if(cpu->IQ[cpu->tailiq].op==LOAD){
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].valid;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].value;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].s2val=cpu->stage[dispatch].sr1;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;

	}
	else if(cpu->IQ[cpu->tailiq].op==STORE){
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].valid;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].value;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].s2val=cpu->stage[dispatch].sr2;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;
	}
	else if(cpu->IQ[cpu->tailiq].op==HALT){
		cpu->IQ[cpu->tailiq].s1valid=1;
		cpu->IQ[cpu->tailiq].s2valid=1;
		cpu->IQ[cpu->tailiq].LP=1;
		cpu->tailiq=cpu->tailiq+1;
	}
	else {
		cpu->IQ[cpu->tailiq].s1valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].valid;
		cpu->IQ[cpu->tailiq].s1tag=cpu->RAT[cpu->stage[dispatch].sr1].prf;
		cpu->IQ[cpu->tailiq].s1val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr1].prf].value;
		
		cpu->IQ[cpu->tailiq].s2valid=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].valid;
		cpu->IQ[cpu->tailiq].s2tag=cpu->RAT[cpu->stage[dispatch].sr2].prf;
		cpu->IQ[cpu->tailiq].s2val=cpu->PRF[cpu->RAT[cpu->stage[dispatch].sr2].prf].value;
		cpu->IQ[cpu->tailiq].LP=2;
		cpu->tailiq=cpu->tailiq+1;
	}
	
	if(cpu->tailiq==10){
		if(cpu->headiq!=0){
			cpu->tailiq=0;
		}
		else{
			cpu->stage[dispatch].status=stage_stalled;
		}
	}
}


/*---------------------------------------------------------
  Execute stage functions
---------------------------------------------------------*/
void add_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1+cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d+%d ",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	//set_conditionCodes(cpu,fu_alu1);
	set_PRF_conditionCodes(cpu,fu_alu1);
	exForward(cpu,fu_alu1);
}

void sub_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1-cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d-%d",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	//set_conditionCodes(cpu,fu_alu1);
	set_PRF_conditionCodes(cpu,fu_alu1);
	exForward(cpu,fu_alu1);
}

void cmp_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1-cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"cc based on %d-%d",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	//set_PRF_conditionCodes(cpu,fu_alu1);
	set_conditionCodes(cpu,fu_alu1);
	// exForward(cpu);
}

void mul_execute(cpu cpu) {
	cpu->stage[fu_mul1].result=cpu->stage[fu_mul1].op1*cpu->stage[fu_mul1].op2;
	cpu->PRF[cpu->stage[fu_mul1].dr].value=cpu->stage[fu_mul1].result;
	reportStage(cpu,fu_mul1,"res=%d*%d",cpu->stage[fu_mul1].op1,cpu->stage[fu_mul1].op2);
	set_PRF_conditionCodes(cpu,fu_mul1);
	//set_conditionCodes(cpu,fu_mul1);
	exForward(cpu,fu_mul1);
}

void and_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1&cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d&%d",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	exForward(cpu,fu_alu1);
}

void or_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1|cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d|%d",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	exForward(cpu,fu_alu1);
}

void xor_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1^cpu->stage[fu_alu1].op2;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d^%d",cpu->stage[fu_alu1].op1,cpu->stage[fu_alu1].op2);
	exForward(cpu,fu_alu1);
}

void movc_execute(cpu cpu) {
	cpu->stage[fu_alu1].result=cpu->stage[fu_alu1].op1;
	cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_alu1,"res=%d",cpu->stage[fu_alu1].result);
	exForward(cpu,fu_alu1);
}

void load_execute(cpu cpu) {
	cpu->stage[fu_ld1].effectiveAddr =
//		cpu->stage[fu_ld1].op1 + cpu->stage[fu_ld1].offset;
cpu->stage[fu_ld1].op1 + cpu->stage[fu_ld1].offset;
cpu->PRF[cpu->stage[fu_alu1].dr].value=cpu->stage[fu_alu1].result;
	reportStage(cpu,fu_ld1,"effAddr=%08x",cpu->stage[fu_ld1].effectiveAddr);
}

void store_execute(cpu cpu) {
	cpu->stage[fu_ld1].effectiveAddr =
		cpu->stage[fu_ld1].op2 + cpu->stage[fu_ld1].imm;
	reportStage(cpu,fu_ld1,"effAddr=%08x",cpu->stage[fu_ld1].effectiveAddr);
}

void cbranch_execute(cpu cpu) {
	if (cpu->stage[fu_br1].branch_taken) {
		// Update PC
		cpu->pc=cpu->stage[fu_br1].pc+cpu->stage[fu_br1].offset;
		reportStage(cpu,fu_br1,"pc=%06x",cpu->pc);
		cpu->halt_fetch=0; // Fetch can start again next cycle
	} else {
		reportStage(cpu,fu_br1,"No action... branch not taken");
	}
}

void fwd_execute(cpu cpu) {
	return;
}

/*---------------------------------------------------------
  Memory  stage functions
---------------------------------------------------------*/
void load_memory(cpu cpu) {
	// cpu->stage[fu_ld2].result = dfetch(cpu,cpu->stage[fu_ld2].effectiveAddr);
	// reportStage(cpu,fu_ld2,"res=MEM[%06x]",cpu->stage[fu_ld2].effectiveAddr);
	// assert(cpu->fwdBus[1].valid==0); // load should not have used the ex forwarding bus
	// cpu->fwdBus[1].tag=cpu->stage[fu_ld2].dr;
	// cpu->fwdBus[1].value=cpu->stage[fu_ld2].result;
	// cpu->fwdBus[1].valid=1;
	return;
}

void store_memory(cpu cpu) {
	// dstore(cpu,cpu->stage[fu_st2].effectiveAddr,cpu->stage[fu_st2].op1);
	// reportStage(cpu,fu_st2,"MEM[%06x]=%d",
	// 	cpu->stage[fu_st2].effectiveAddr,
	// 	cpu->stage[fu_st2].op1);
	return;
}

/*---------------------------------------------------------
  Writeback stage functions
---------------------------------------------------------*/
void dest_writeback(cpu cpu) {
	int reg=cpu->stage[writeback].dr;
//	cpu->reg[reg]=cpu->stage[writeback].result;
//	cpu->regValid[reg]=1;
	cpu->reg[reg]=cpu->PRF[cpu->stage[writeback].dr].value;
	cpu->regValid[reg]=1;	
	cpu->rob_struct[cpu->headrob].alloc=-1;
	cpu->headrob=cpu->headrob+1;
	cpu->cc.z=cpu->PRF[cpu->stage[writeback].dr].zcc;
	cpu->cc.p=cpu->PRF[cpu->stage[writeback].dr].pcc;
	reportStage(cpu,writeback,"R%02d<-%d",reg,cpu->stage[writeback].result);
}
void comp_retire(cpu cpu){
	cpu->cc.p=cpu->PRF[cpu->stage[writeback].dr].pcc;
	cpu->cc.p=cpu->PRF[cpu->stage[writeback].dr].zcc;
	
}
void halt_writeback(cpu cpu) {
	cpu->stop=1;
	strcpy(cpu->abend,"HALT instruction retired");
	reportStage(cpu,writeback,"cpu stopped");
}

/*---------------------------------------------------------
  Externally available functions
---------------------------------------------------------*/
void registerAllOpcodes() {
	// Invoke registerOpcode for EACH valid opcode here
	registerOpcode(ADD,alu_fu,dss_decode,dispatch_inst,add_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(ADDL,alu_fu,dsi_decode,dispatch_inst,add_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(SUB,alu_fu,dss_decode,dispatch_inst,sub_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(SUBL,alu_fu,dsi_decode,dispatch_inst,sub_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(MUL,mult_fu,dss_decode,dispatch_inst,mul_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(AND,alu_fu,dss_decode,dispatch_inst,and_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(OR,alu_fu,dss_decode,dispatch_inst,or_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(XOR,alu_fu,dss_decode,dispatch_inst,xor_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(MOVC,alu_fu,movc_decode,dispatch_inst,movc_execute,fwd_execute,fwd_execute,dest_writeback);
	registerOpcode(LOAD,load_fu,dsi_decode,dispatch_inst,load_execute,fwd_execute,dest_writeback,load_memory);
	registerOpcode(STORE,load_fu,ssi_decode,dispatch_inst,store_execute,fwd_execute,fwd_execute,store_memory);
	registerOpcode(CMP,alu_fu,ssi_decode,dispatch_inst,cmp_execute,fwd_execute,fwd_execute,comp_retire);
	registerOpcode(JUMP,br_fu,cbranch_decode,dispatch_inst,cbranch_execute,fwd_execute,fwd_execute,NULL);
	registerOpcode(BZ,br_fu,cbranch_decode,dispatch_inst,cbranch_execute,fwd_execute,fwd_execute,NULL);
	registerOpcode(BNZ,br_fu,cbranch_decode,dispatch_inst,cbranch_execute,fwd_execute,fwd_execute,NULL);
	registerOpcode(BP,br_fu,cbranch_decode,dispatch_inst,cbranch_execute,fwd_execute,fwd_execute,NULL);
	registerOpcode(BNP,br_fu,cbranch_decode,dispatch_inst,cbranch_execute,fwd_execute,fwd_execute,NULL);
	registerOpcode(HALT,alu_fu,NULL,dispatch_inst,fwd_execute,fwd_execute,fwd_execute,halt_writeback);
}

void registerOpcode(int opNum,enum fu_enum fu,
	opStageFn decodeFn,opStageFn dispatchfn,opStageFn executeFn1,
	opStageFn executeFn2,opStageFn executeFn3,
	opStageFn writebackFn) {

	opFns[decode][opNum]=decodeFn;
	opFns[dispatch][opNum]=dispatchfn;
	opFns[fu][opNum]=executeFn1;
	opFns[fu+1][opNum]=executeFn2;
	opFns[fu+2][opNum]=executeFn3;
	opFns[writeback][opNum]=writebackFn;
}

char * disassemble(int instruction,char *buf) {
	// assumes buf is big enough to hold the full disassemble string (max is probably 32)
	int opcode=(instruction>>24);
	if (opcode>HALT || opcode<0) {
		printf("In disassemble, invalid opcode: %d\n",opcode);
		strcpy(buf,"????");
		return buf;
	}
	buf[0]='\0';
	int dr,sr1,sr2,offset;
	short imm;
	enum opFormat_enum fmt=opInfo[opcode].format;
	switch(fmt) {
		case fmt_nop:
			sprintf(buf,"%s",opInfo[opcode].mnemonic);
			break;
		case fmt_dss:
			dr=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			sr2=(instruction&0x0000f000)>>12;
			sprintf(buf,"%s R%02d,R%02d,R%02d",opInfo[opcode].mnemonic,dr,sr1,sr2);
			break;
		case fmt_dsi:
			dr=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,R%02d,#%d",opInfo[opcode].mnemonic,dr,sr1,imm);
			break;
		case fmt_di:
			dr=(instruction&0x00f00000)>>20;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,#%d",opInfo[opcode].mnemonic,dr,imm);
			break;
		case fmt_ssi:
			sr2=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,R%02d,#%d",opInfo[opcode].mnemonic,sr2,sr1,imm);
			break;
		case fmt_ss:
			sr1=(instruction&0x000f0000)>>16;
			sr2=(instruction&0x0000f000)>>12;
			sprintf(buf,"%s R%02d,R%02d",opInfo[opcode].mnemonic,sr1,sr2);
			break;
		case fmt_off:
			offset=((instruction&0x00ffffff)<<8)>>8; // shift left 8, then right 8 to propagate sign bit
			sprintf(buf,"%s #%d",opInfo[opcode].mnemonic,offset);
			break;
		default :
			printf("In disassemble, format not recognized: %d\n",fmt);
			strcpy(buf,"????");
	}
	return buf;
}


int fetchRegister(cpu cpu,int reg,int *value) {
	// Check forwarding busses in program order
	for (int fb=0;fb<3;fb++) {
		if (cpu->fwdBus[fb].valid && reg==cpu->fwdBus[fb].tag) {
			(*value)=cpu->fwdBus[fb].value;
			return 1;
		}
	}
	if (cpu->regValid[reg]) {
		(*value)=cpu->reg[reg];
		return 1;
	}
	return 0;
}

/*---------------------------------------------------------
  Internal helper functions
---------------------------------------------------------*/
void fetch_register1(cpu cpu) {
	cpu->stage[decode].op1Valid=fetchRegister(cpu,cpu->stage[decode].sr1,&cpu->stage[decode].op1);
	if (cpu->stage[decode].op1Valid) {
		reportStage(cpu,decode," R%d=%d",cpu->stage[decode].sr1,cpu->stage[decode].op1);
	} else {
		reportStage(cpu,decode," R%d invalid",cpu->stage[decode].sr1);
	}

}

void fetch_register2(cpu cpu) {
	cpu->stage[decode].op2Valid=fetchRegister(cpu,cpu->stage[decode].sr2,&cpu->stage[decode].op2);
	if (cpu->stage[decode].op2Valid) {
		reportStage(cpu,decode," R%d=%d",cpu->stage[decode].sr2,cpu->stage[decode].op2);
	} else {
		reportStage(cpu,decode," R%d invalid",cpu->stage[decode].sr2);
	}
}

//void check_dest(cpu cpu) {
	// int reg=cpu->stage[decode].dr;
	// cpu->RAT[reg].valid=1;
	// cpu->RAT[reg].prf=cpu->nextfreeprf;
	// cpu->PRF[cpu->nextfreeprf].valid=0;
	
	// if (!cpu->regValid[reg]) {
	// 	cpu->stage[decode].status=stage_stalled;
	// 	reportStage(cpu,decode," R%d invalid",reg);
	// }
	// if (cpu->stage[decode].status!=stage_stalled)  {
	// 	 cpu->regValid[cpu->stage[decode].dr]=0;
	// 	 reportStage(cpu,decode," invalidate R%d",reg);
	// }
	

//}
void check_dest(cpu cpu) {
	int reg=cpu->stage[decode].dr;
	cpu->RAT[reg].valid=1;
	cpu->RAT[reg].prf=cpu->nextfreeprf;
	cpu->PRF[cpu->nextfreeprf].valid=0;

	if( cpu->stage[decode].opcode==ADD|| cpu->stage[decode].opcode==ADDL || cpu->stage[decode].opcode==SUBL|| cpu->stage[decode].opcode==SUB || cpu->stage[decode].opcode==CMP || cpu->stage[decode].opcode==MUL ){
		cpu->cc.prf_cc=cpu->RAT[reg].prf;
		// printf("This is %d",cpu->RAT[reg].prf);
	}
	if (!cpu->regValid[reg]) {
		cpu->stage[decode].status=stage_stalled;
		reportStage(cpu,decode," R%d invalid",reg);
	}
	if (cpu->stage[decode].status!=stage_stalled)  {
		 cpu->regValid[cpu->stage[decode].dr]=0;
		 reportStage(cpu,decode," invalidate R%d",reg);
	}
	
}
void add_rob(cpu cpu){
	if(cpu->stage[decode].status!= stage_stalled){
	//for (int i=0;i<16;i++){
		//printf("The tail pointer:%d\n", cpu->tailrob);
		if(cpu->rob_struct[cpu->tailrob].alloc == -1){
			{
			cpu->rob_struct[cpu->tailrob].alloc = 1;
			//cpu->rob_struct[cpu->tailrob].opcode=cpu->stage[decode].opcode;
			if(cpu->stage[decode].opcode==13 ||cpu->stage[decode].opcode == 14 ||cpu->stage[decode].opcode == 15 || cpu->stage[decode].opcode == 16|| cpu->stage[decode].opcode == 17){
				//cpu->rob_struct[cpu->tailrob].ar_val =;
				cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;
				//cpu->rob_struct[cpu->tailrob].pr_val = cpu->nextfreeprf;
				cpu->tailrob=cpu->tailrob+1;
				}
			else if(cpu->stage[decode].dr!=-1){
				if(cpu->stage[decode].opcode==18){
				cpu->rob_struct[cpu->tailrob].ar_val = 0;
				cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;
				cpu->tailrob=cpu->tailrob+1;
				}else if(cpu->stage[decode].opcode== 11){
					cpu->rob_struct[cpu->tailrob].ar_val = cpu->stage[decode].sr1;
					cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;
				//	cpu->rob_struct[cpu->tailrob].pr_val = cpu->RAT[cpu->rob_struct[cpu->tailrob].ar_val].prf;
					cpu->tailrob=cpu->tailrob+1;
				}else if(cpu->stage[decode].opcode== 12){
				//cpu->rob_struct[cpu->tailrob].ar_val = cpu->stage[decode].sr1;
				cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;
				//cpu->rob_struct[cpu->tailrob].pr_val = cpu->nextfreeprf;//cpu->RAT[cpu->rob_struct[cpu->tailrob].ar_val].prf;
				cpu->tailrob=cpu->tailrob+1;
				}
				else {
				cpu->rob_struct[cpu->tailrob].ar_val = cpu->stage[decode].dr;
				cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;
				cpu->rob_struct[cpu->tailrob].pr_val = cpu->RAT[cpu->rob_struct[cpu->tailrob].ar_val].prf;
				//cpu->rob_struct[cpu->tailrob].alloc = 1;
				//cpu->rob_struct[cpu->tailiq].op=cpu->stage[decode].opcode;
				cpu->tailrob=cpu->tailrob+1;
				  if(cpu->tailrob==16){
					if(cpu->headrob!=0){
				cpu->tailrob=0;
		      }
		   else{
			cpu->stage[decode].status=stage_stalled;
		   }
	}

				}

			}
			//break;
			}
				//break;
        }

}
else if(cpu->stage[decode].status!= stage_stalled){
 cpu->rob_struct[cpu->tailrob].pc_val = cpu->stage[decode].pc;	
}
}

void add_lsq(cpu cpu){
	//if(cpu->stage[decode].opcode == 10 || cpu->stage[decode].opcode == 11){
		//int lsq_counter =0;
		if(cpu->LSQ_struct[cpu->taillsq].a == -1){
			cpu->LSQ_struct[cpu->taillsq].a = 1;
			if(cpu->stage[decode].opcode == 10){
				cpu->LSQ_struct[cpu->taillsq].ls = 1;
				for(int i=0;i<16;i++){
					if (cpu->rob_struct[i].ar_val == cpu->stage[decode].dr){
						cpu->LSQ_struct[cpu->taillsq].dest = cpu->rob_struct[i].pr_val;
						cpu->rob_struct[i].ls_index = cpu->lsqindex;
						cpu->LSQ_struct[i].addv = 0;
						cpu->LSQ_struct[i].addval = 0xdeadbeef;
						break;
				}
				}//cpu->rob_struct[cpu->taillsq].pr_val; cpu->stage[decode].dr
			//	cpu->taillsq=cpu->taillsq+1;
			//	cpu->lsqindex=cpu->lsqindex+1;//lsq_counter +1;
			}
			else if(cpu->stage[decode].opcode == 11){
				cpu->LSQ_struct[cpu->taillsq].ls = 2;
				for(int i=0;i<16;i++){
					if (cpu->rob_struct[i].ar_val == cpu->stage[decode].sr1){
						cpu->LSQ_struct[i].addv =0;
						cpu->LSQ_struct[i].v=0;
						cpu->rob_struct[i].ls_index = cpu->lsqindex;
					}
				}
				//cpu->LSQ_struct[cpu->taillsq].dest = -1;
				// cpu->taillsq=cpu->taillsq+1;
				// cpu->lsqindex=cpu->lsqindex+1;
			}
				cpu->taillsq=cpu->taillsq+1;
				//printf("\nthis is lsqindex:\n%d",cpu->lsqindex);
				cpu->lsqindex=cpu->lsqindex+1;
				
		} 
	//}
}
void set_ARF_conditionCodes(cpu cpu,enum stage_enum stage) {
	// Condition codes always set during the execute phase
	if (cpu->stage[stage].result==0) cpu->cc.z=1;
	else cpu->cc.z=0;
	if (cpu->stage[stage].result>0) cpu->cc.p=1;
	else cpu->cc.p=0;
}

void set_PRF_conditionCodes(cpu cpu,enum stage_enum stage){
	// Condition codes always set during the execute phase
	if (cpu->stage[stage].result==0) cpu->PRF[cpu->stage[stage].dr].zcc=1;
	else cpu->PRF[cpu->stage[stage].dr].zcc=0;
	if (cpu->stage[stage].result>0) cpu->PRF[cpu->stage[stage].dr].pcc=1;
	else cpu->PRF[cpu->stage[stage].dr].pcc=0;

}
void set_conditionCodes(cpu cpu,enum stage_enum stage) {
	// Condition codes always set during the execute phase
	if (cpu->stage[stage].result==0) cpu->cc.z=1;
	else cpu->cc.z=0;
	if (cpu->stage[stage].result>0) cpu->cc.p=1;
	else cpu->cc.p=0;
}

void exForward(cpu cpu,enum stage_enum stage) {
	cpu->fwdBus[0].tag=cpu->stage[stage].dr;
	cpu->fwdBus[0].value=cpu->stage[stage].result;
	cpu->fwdBus[0].valid=1;

	int x=cpu->RAT[cpu->fwdBus[0].tag].prf;
	cpu->PRF[x].value=cpu->fwdBus[0].value;
	cpu->PRF[x].valid=1;
	
}