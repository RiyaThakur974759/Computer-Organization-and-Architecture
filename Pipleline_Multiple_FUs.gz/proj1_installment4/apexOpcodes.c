#include "apexOpcodes.h"
#include "apexCPU.h"
#include "apexMem.h"
#include "apexOpInfo.h" // OpInfo definition
#include <string.h>
#include <stdio.h>
#include <assert.h>

/*---------------------------------------------------------
This file contains a C function for each opcode and
stage that needs to do work for that opcode in that
stage.

When functions for a specific opcode are registered,
the simulator will invoke that function for that operator
when the corresponding stage is cycled. A NULL
function pointer for a specific opcode/stage indicates
that no processing is required for that operation and
stage.

The registerAllOpcodes function should invoke the
registerOpcode function for EACH valid opcode. If
you add new opcodes to be simulated, code the
functions for each stage for that opcode, and add
an invocation of registerOpcode to the
registerAllOpcodes function.
---------------------------------------------------------*/

/*---------------------------------------------------------
  Helper Function Declarations
---------------------------------------------------------*/
void fetch_register1(cpu cpu);
void fetch_register2(cpu cpu);
void check_dest(cpu cpu);
void set_conditionCodes(cpu cpu, int fu_stage);
void exForward(cpu cpu, int fu_stage);

/*---------------------------------------------------------
  Global Variables
---------------------------------------------------------*/
opStageFn opFns[18][NUMOPS]={NULL}; // Array of function pointers, one for each stage/opcode combination


/*---------------------------------------------------------
  Decode stage functions
---------------------------------------------------------*/
void dss_decode(cpu cpu) {
	cpu->stage[decode].status=stage_noAction;
	fetch_register1(cpu);
	fetch_register2(cpu);
	check_dest(cpu);
	if(cpu->stage[decode].opcode==MUL){
		cpu->stage[decode].fu=mulfn;
	}
	else{
		cpu->stage[decode].fu=alufn;
	}
}
void dsi_decode(cpu cpu) {
	cpu->stage[decode].status=stage_noAction;
	fetch_register1(cpu);
	check_dest(cpu);
	if(cpu->stage[decode].opcode==LOAD){
		cpu->stage[decode].fu=lodfn;
	}
	else{
		cpu->stage[decode].fu=alufn;
	}
}

void ssi_decode(cpu cpu) {
	cpu->stage[decode].status=stage_noAction;
	fetch_register1(cpu);
	fetch_register2(cpu);
	if(cpu->stage[decode].opcode==STORE){
		cpu->stage[decode].fu=stofn;
	}
	else{
		cpu->stage[decode].fu=alufn;
	}
}

void movc_decode(cpu cpu) {
	cpu->stage[decode].status=stage_noAction;
	check_dest(cpu);
	cpu->stage[decode].fu=alufn;
}

void cbranch_decode(cpu cpu) {
	cpu->stage[decode].branch_taken=0;
	if (cpu->stage[decode].opcode==JUMP) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BZ && cpu->cc.z) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BNZ && !cpu->cc.z) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BP && cpu->cc.p) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].opcode==BNP && !cpu->cc.p) cpu->stage[decode].branch_taken=1;
	if (cpu->stage[decode].branch_taken) {
		// Squash instruction currently in fetch
		cpu->stage[fetch].instruction=0;
		cpu->stage[fetch].status=stage_squashed;
		reportStage(cpu,fetch," squashed by previous branch");
		cpu->halt_fetch=1;
		reportStage(cpu,decode," branch taken");
	} else {
	  reportStage(cpu,decode," branch not taken");
  }
	cpu->stage[decode].fu=brfn;
}

/*---------------------------------------------------------
  fu_stage stage functions
---------------------------------------------------------*/
void add_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1+cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"res=%d+%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	set_conditionCodes(cpu, alu1);
	exForward(cpu, alu1);
}

void sub_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1-cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"res=%d-%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	set_conditionCodes(cpu, alu1);
	exForward(cpu, alu1);
}

void cmp_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1-cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"cc based on %d-%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	set_conditionCodes(cpu, alu1);
	// exForward(cpu, alu1);
}

void mul_fu_stage(cpu cpu) {
	cpu->stage[mul1].result=cpu->stage[mul1].op1*cpu->stage[mul1].op2;
	reportStage(cpu,mul1,"res=%d*%d",cpu->stage[mul1].op1,cpu->stage[mul1].op2);
	set_conditionCodes(cpu, mul1);
	exForward(cpu, mul1);
}

void and_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1&cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"res=%d&%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	exForward(cpu, alu1);
}

void or_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1|cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"res=%d|%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	exForward(cpu, alu1);
}

void xor_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1^cpu->stage[alu1].op2;
	reportStage(cpu,alu1,"res=%d^%d",cpu->stage[alu1].op1,cpu->stage[alu1].op2);
	exForward(cpu, alu1);
}

void movc_fu_stage(cpu cpu) {
	cpu->stage[alu1].result=cpu->stage[alu1].op1;
	reportStage(cpu,alu1,"res=%d",cpu->stage[alu1].result);
	exForward(cpu, alu1);
}

void load_fu_stage(cpu cpu) {
	cpu->stage[lod1].effectiveAddr =
		cpu->stage[lod1].op1 + cpu->stage[lod1].imm;
	reportStage(cpu,lod1,"effAddr=%08x",cpu->stage[lod1].effectiveAddr);
}
void store_fu_stage(cpu cpu) {
	cpu->stage[sto1].effectiveAddr =
		cpu->stage[sto1].op1 + cpu->stage[sto1].imm;
	reportStage(cpu,sto1,"effAddr=%08x",cpu->stage[sto1].effectiveAddr);
}

void cbranch_fu_stage(cpu cpu) {
	if (cpu->stage[br1].branch_taken) {
		// Update PC
		cpu->pc=cpu->stage[br1].pc+cpu->stage[br1].offset;
		reportStage(cpu,br1,"pc=%06x",cpu->pc);
		cpu->halt_fetch=0; // Fetch can start again next cycle
	} else {
		reportStage(cpu,br1,"No action... branch not taken");
	}
}

/*---------------------------------------------------------
  Memory  stage functions
---------------------------------------------------------*/
void load_memory(cpu cpu) {
	cpu->stage[lod3].result = dfetch(cpu,cpu->stage[lod3].effectiveAddr);
	reportStage(cpu,lod3,"res=MEM[%06x]",cpu->stage[lod3].effectiveAddr);
	assert(cpu->mem_fwdBus.valid==0); // load should not have used the ex forwarding bus
	cpu->mem_fwdBus.tag=cpu->stage[lod3].dr;
	cpu->mem_fwdBus.value=cpu->stage[lod3].result;
	cpu->mem_fwdBus.valid=1;
}

void store_memory(cpu cpu) {
	dstore(cpu,cpu->stage[sto3].effectiveAddr,cpu->stage[sto3].op2);
	reportStage(cpu,sto3,"MEM[%06x]=%d",
		cpu->stage[sto3].effectiveAddr,
		cpu->stage[sto3].op1);
}

/*---------------------------------------------------------
  Writeback stage functions
---------------------------------------------------------*/
void dest_writeback(cpu cpu) {
	int reg=cpu->stage[writeback].dr;
	cpu->reg[reg]=cpu->stage[writeback].result;
	cpu->regValid[reg]=1;
	reportStage(cpu,writeback,"R%02d<-%d",reg,cpu->stage[writeback].result);
}

void halt_writeback(cpu cpu) {
	cpu->stop=1;
	strcpy(cpu->abend,"HALT instruction retired");
	reportStage(cpu,writeback,"cpu stopped");
}



////trial
/*---------------------------------------------------------
  Externally available functions
---------------------------------------------------------*/
void registerAllOpcodes() {
	// Invoke registerOpcode for EACH valid opcode here
	registerOpcode(ADD,dss_decode,add_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(ADDL,dsi_decode,add_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(SUB,dss_decode,sub_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(SUBL,dsi_decode,sub_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(MUL,dss_decode,NULL,NULL,NULL,mul_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(AND,dss_decode,and_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(OR,dss_decode,or_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(XOR,dss_decode,xor_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(MOVC,movc_decode,movc_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(LOAD,dsi_decode,NULL,NULL,NULL,NULL,NULL,NULL,load_fu_stage,NULL,load_memory,NULL,NULL,NULL,NULL,NULL,NULL,dest_writeback);
	registerOpcode(STORE,ssi_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,store_fu_stage,NULL,store_memory,NULL,NULL,NULL,NULL);
	registerOpcode(CMP,ssi_decode,cmp_fu_stage,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
	registerOpcode(JUMP,cbranch_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,cbranch_fu_stage,NULL,NULL,NULL);
	registerOpcode(BZ,cbranch_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,cbranch_fu_stage,NULL,NULL,NULL);
	registerOpcode(BNZ,cbranch_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,cbranch_fu_stage,NULL,NULL,NULL);
	registerOpcode(BP,cbranch_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,cbranch_fu_stage,NULL,NULL,NULL);
	registerOpcode(BNP,cbranch_decode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,cbranch_fu_stage,NULL,NULL,NULL);
	registerOpcode(HALT,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,halt_writeback);
}

void registerOpcode(int opNum,
	opStageFn decodeFn,
	opStageFn alufn1,opStageFn alufn2,opStageFn alufn3,
	opStageFn mulfn1,opStageFn mulfn2,opStageFn mulfn3,
	opStageFn lo1,opStageFn lo2,opStageFn lo3,
	opStageFn st1,opStageFn st2,opStageFn st3,
	opStageFn b1,opStageFn b2,opStageFn b3,opStageFn writebackFn) {

	opFns[decode][opNum]=decodeFn;
	opFns[alu1][opNum]=alufn1;
	opFns[alu2][opNum]=alufn2;
	opFns[alu3][opNum]=alufn3;
	opFns[mul1][opNum]=mulfn1;
	opFns[mul2][opNum]=mulfn2;
	opFns[mul3][opNum]=mulfn3;
	opFns[lod1][opNum]=lo1;
	opFns[lod2][opNum]=lo2;
	opFns[lod3][opNum]=lo3;
	opFns[sto1][opNum]=st1;
	opFns[sto2][opNum]=st2;
	opFns[sto3][opNum]=st3;
	opFns[br1][opNum]=b1;
	opFns[br2][opNum]=b2;
	opFns[br3][opNum]=b3;
	opFns[writeback][opNum]=writebackFn;
}

char * disassemble(int instruction,char *buf) {
	// assumes buf is big enough to hold the full disassemble string (max is probably 32)
	int opcode=(instruction>>24);
	if (opcode>HALT || opcode<0) {
		printf("In disassemble, invalid opcode: %d\n",opcode);
		strcpy(buf,"????");
		return buf;
	}
	buf[0]='\0';
	int dr,sr1,sr2,offset;
	short imm;
	enum opFormat_enum fmt=opInfo[opcode].format;
	switch(fmt) {
		case fmt_nop:
			sprintf(buf,"%s",opInfo[opcode].mnemonic);
			break;
		case fmt_dss:
			dr=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			sr2=(instruction&0x0000f000)>>12;
			sprintf(buf,"%s R%02d,R%02d,R%02d",opInfo[opcode].mnemonic,dr,sr1,sr2);
			break;
		case fmt_dsi:
			dr=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,R%02d,#%d",opInfo[opcode].mnemonic,dr,sr1,imm);
			break;
		case fmt_di:
			dr=(instruction&0x00f00000)>>20;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,#%d",opInfo[opcode].mnemonic,dr,imm);
			break;
		case fmt_ssi:
			sr2=(instruction&0x00f00000)>>20;
			sr1=(instruction&0x000f0000)>>16;
			imm=(instruction&0x0000ffff);
			sprintf(buf,"%s R%02d,R%02d,#%d",opInfo[opcode].mnemonic,sr2,sr1,imm);
			break;
		case fmt_ss:
			sr1=(instruction&0x000f0000)>>16;
			sr2=(instruction&0x0000f000)>>12;
			sprintf(buf,"%s R%02d,R%02d",opInfo[opcode].mnemonic,sr1,sr2);
			break;
		case fmt_off:
			offset=((instruction&0x00ffffff)<<8)>>8; // shift left 8, then right 8 to propagate sign bit
			sprintf(buf,"%s #%d",opInfo[opcode].mnemonic,offset);
			break;
		default :
			printf("In disassemble, format not recognized: %d\n",fmt);
			strcpy(buf,"????");
	}
	return buf;
}

/*---------------------------------------------------------
  Internal helper functions
---------------------------------------------------------*/
void fetch_register1(cpu cpu) {
	int reg=cpu->stage[decode].sr1;
	// Check forwarding busses in program order
	if (cpu->ex_fwdBus.valid && reg==cpu->ex_fwdBus.tag) {
		cpu->stage[decode].op1=cpu->ex_fwdBus.value;
		reportStage(cpu,decode," R%d=%d fwd from EX",reg,cpu->ex_fwdBus.value);
		return;
	}
	if (cpu->mem_fwdBus.valid && reg==cpu->mem_fwdBus.tag) {
		cpu->stage[decode].op1=cpu->mem_fwdBus.value;
		reportStage(cpu,decode," R%d=%d fwd from MEM",reg,cpu->mem_fwdBus.value);
		return;
	}
	if (cpu->regValid[reg]) {
		cpu->stage[decode].op1=cpu->reg[reg];
		reportStage(cpu,decode," R%d=%d",reg,cpu->reg[reg]);
		return;
	}
	// Register value cannot be found
	cpu->stage[decode].status=stage_stalled;
	reportStage(cpu,decode," R%d invalid",reg);
	return;
}

void fetch_register2(cpu cpu) {
	int reg=cpu->stage[decode].sr2;
	// Check forwarding busses in program order
	if (cpu->ex_fwdBus.valid && reg==cpu->ex_fwdBus.tag) {
		cpu->stage[decode].op2=cpu->ex_fwdBus.value;
		reportStage(cpu,decode," R%d=%d fwd from EX",reg,cpu->ex_fwdBus.value);
		return;
	}
	if (cpu->mem_fwdBus.valid && reg==cpu->mem_fwdBus.tag) {
		cpu->stage[decode].op2=cpu->mem_fwdBus.value;
		reportStage(cpu,decode," R%d=%d fwd from MEM",reg,cpu->mem_fwdBus.value);
		return;
	}
	if (cpu->regValid[reg]) {
		cpu->stage[decode].op2=cpu->reg[reg];
		reportStage(cpu,decode," R%d=%d",reg,cpu->reg[reg]);
		return;
	}
	// reg2 value cannot be found
	cpu->stage[decode].status=stage_stalled;
	reportStage(cpu,decode," R%d invalid",reg);
}

void check_dest(cpu cpu) {
	int reg=cpu->stage[decode].dr;
	if (!cpu->regValid[reg]) {
		cpu->stage[decode].status=stage_stalled;
		reportStage(cpu,decode," R%d invalid",reg);
	}
	if (cpu->stage[decode].status!=stage_stalled)  {
		 cpu->regValid[cpu->stage[decode].dr]=0;
		 reportStage(cpu,decode," invalidate R%d",reg);
	}
}

void set_conditionCodes(cpu cpu, int fu_stage) {
	// Condition codes always set during the fu_stage phase
	if (cpu->stage[fu_stage].result==0) cpu->cc.z=1;
	else cpu->cc.z=0;
	if (cpu->stage[fu_stage].result>0) cpu->cc.p=1;
	else cpu->cc.p=0;
}

void exForward(cpu cpu,int fu_stage) {
	cpu->ex_fwdBus.tag=cpu->stage[fu_stage].dr;
	cpu->ex_fwdBus.value=cpu->stage[fu_stage].result;
	cpu->ex_fwdBus.valid=1;
}